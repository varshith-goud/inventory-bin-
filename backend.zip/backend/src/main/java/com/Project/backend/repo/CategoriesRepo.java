package com.Project.backend.repo;


import com.Project.backend.model.Categories;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CategoriesRepo extends JpaRepository<Categories,Long> {

        boolean existsByNameIgnoreCase(String name);

}
