package com.Project.backend.controller;

import com.Project.backend.model.Suppliers;
import com.Project.backend.service.SupplierService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/suppliers")
@RequiredArgsConstructor
//@CrossOrigin("http://localhost:5173")
public class SuppliersController {

    private final SupplierService supplierService;

    @GetMapping
    public List<Suppliers> getAll() {
        return supplierService.getAll();
    }

    @GetMapping("/{id}")
    public Suppliers getById(@PathVariable Long id) {
        return supplierService.getById(id);
    }

    @PostMapping
    public Suppliers create(@RequestBody Suppliers supplier) {
        return supplierService.create(supplier);
    }

    @PutMapping("/{id}")
    public Suppliers update(@PathVariable Long id, @RequestBody Suppliers supplier) {
        return supplierService.update(id, supplier);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        supplierService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
