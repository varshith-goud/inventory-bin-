package com.Project.backend.service;


import com.Project.backend.exception.ResourceNotFoundException;
import com.Project.backend.model.Categories;

import com.Project.backend.repo.CategoriesRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CategoryService {


    private final CategoriesRepo categoriesRepo;

    public List<Categories> getAll(){
        return categoriesRepo.findAll();
    }

    public Categories create(Categories cat){


        if (categoriesRepo.existsByNameIgnoreCase(cat.getName())) {
            throw new IllegalArgumentException("Category '" + cat.getName() + "' already exists");
        }
        return categoriesRepo.save(cat);
    }

    public Categories getById(Long id){
        return categoriesRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Item not found with id: " + id));
    }

    public Categories update(Long id,Categories cat){
        Categories current=getById(id);
        current.setName(cat.getName());
        current.setDescription(cat.getDescription());
        return categoriesRepo.save(current);
    }

    public void delete(Long id){
        categoriesRepo.deleteById(id);
    }

}
