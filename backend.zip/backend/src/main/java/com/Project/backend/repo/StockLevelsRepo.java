package com.Project.backend.repo;

import com.Project.backend.model.StockLevels;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StockLevelsRepo extends JpaRepository<StockLevels, Long> {

    Optional<StockLevels> findByItemId(Long itemId);

    @Query("SELECT s FROM StockLevels s WHERE s.qty < s.minQty")
    List<StockLevels> findItemsBelowMin();

    @Query("SELECT s FROM StockLevels s WHERE LOWER(s.item.name) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(s.item.sku) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    Page<StockLevels> searchByKeyword(@Param("keyword") String keyword, Pageable pageable);

    // Filter by category with pagination
    @Query("SELECT s FROM StockLevels s WHERE s.item.category.id = :categoryId")
    Page<StockLevels> findByCategoryId(@Param("categoryId") Long categoryId, Pageable pageable);

    // Search + category filter combined
    @Query("SELECT s FROM StockLevels s WHERE s.item.category.id = :categoryId AND (LOWER(s.item.name) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(s.item.sku) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    Page<StockLevels> searchByKeywordAndCategory(@Param("keyword") String keyword, @Param("categoryId") Long categoryId, Pageable pageable);
}