package com.Project.backend.controller;


import com.Project.backend.model.Categories;
import com.Project.backend.repo.CategoriesRepo;
import com.Project.backend.service.CategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/categories")
@RequiredArgsConstructor
//@CrossOrigin("http://localhost:5173")
public class CategoriesController {


    private final CategoryService categoryService;

    @GetMapping
    public List<Categories> getAll(){
        return categoryService.getAll();
    }

    @GetMapping("/{id}")
   public Categories getById(@PathVariable Long id){
        return categoryService.getById(id);
   }

   @PostMapping
    public Categories create(@RequestBody Categories category){
        return categoryService.create(category);
   }

   @PutMapping("/{id}")
    public Categories update(@PathVariable Long id,@RequestBody Categories category){
        return categoryService.update(id,category);
   }

   @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id){
        categoryService.delete(id);
        return ResponseEntity.ok().build();
   }
}
