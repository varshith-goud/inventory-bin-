package com.Project.backend.service;

import com.Project.backend.model.Suppliers;
import com.Project.backend.repo.SupplierRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class SupplierService {

    private final SupplierRepo suppliersRepository;

    public List<Suppliers> getAll() {
        return suppliersRepository.findAll();
    }

    public Suppliers getById(Long id) {
        return suppliersRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Supplier not found with id: " + id));
    }

    public Suppliers create(Suppliers supplier) {
        if (suppliersRepository.existsByNameIgnoreCase(supplier.getName())) {
            throw new IllegalArgumentException("Supplier '" + supplier.getName() + "' already exists");
        }
        return suppliersRepository.save(supplier);
    }

    public Suppliers update(Long id, Suppliers updated) {
        Suppliers existing = getById(id);
        existing.setName(updated.getName());
        existing.setEmail(updated.getEmail());
        existing.setPhone(updated.getPhone());
        existing.setAddress(updated.getAddress());
        return suppliersRepository.save(existing);
    }

    public void delete(Long id) {
        suppliersRepository.deleteById(id);
    }
}