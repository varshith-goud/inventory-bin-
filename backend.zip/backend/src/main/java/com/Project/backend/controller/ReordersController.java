package com.Project.backend.controller;

import com.Project.backend.model.ReorderStatus;
import com.Project.backend.model.Reorders;
import com.Project.backend.service.InventoryService;
import com.Project.backend.service.ReordersService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reorders")
@RequiredArgsConstructor
//@CrossOrigin("http://localhost:5173")
public class ReordersController {

    private final ReordersService reordersService;

    private final InventoryService inventoryService;

    @GetMapping
    public List<Reorders> getAll(){
     return reordersService.getAll();
    }

    @GetMapping("/{id}")
    public Reorders getById(@PathVariable Long id) {
        return reordersService.getById(id);
    }

    @GetMapping("/status/{status}")
    public List<Reorders> getByStatus(@PathVariable ReorderStatus status) {
        return reordersService.getByStatus(status);
    }

    @PostMapping
    public Reorders create(@RequestBody Reorders reorder) {
        return reordersService.create(reorder);
    }

    @PutMapping("/{id}/status")
    public Reorders updateStatus(@PathVariable Long id, @RequestParam ReorderStatus status) {
        return reordersService.updateStatus(id, status);
    }

    // triggers the auto-reorder logic
    @PostMapping("/suggest")
    public List<Reorders> suggestReorders() {
        return inventoryService.suggestReorder();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        reordersService.delete(id);
        return ResponseEntity.noContent().build();
    }

}
