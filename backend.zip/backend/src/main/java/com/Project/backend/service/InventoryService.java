package com.Project.backend.service;

import com.Project.backend.model.ReorderStatus;
import com.Project.backend.model.Reorders;
import com.Project.backend.model.StockLevels;
import com.Project.backend.repo.ReordersRepo;
import com.Project.backend.repo.StockLevelsRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class InventoryService {

    private final StockLevelsRepo stockLevelsRepository;
    private final ReordersRepo reordersRepository;

    @Scheduled(fixedRate = 60000)
    public void scheduledReorderCheck() {
        List<Reorders> created = suggestReorder();
        if (!created.isEmpty()) {
            System.out.println("Auto-suggest: " + created.size() + " new reorder(s) created");
        }
    }

    public List<Reorders> suggestReorder() {

        List<Reorders> newReorders = new ArrayList<>();

        // Step 1: find all items where qty < minQty
        List<StockLevels> lowStock = stockLevelsRepository.findItemsBelowMin();

        for (StockLevels stock : lowStock) {

            // Step 2: check if a PENDING or ORDERED reorder already exists for this item
            Optional<Reorders> pendingReorder = reordersRepository
                    .findByItemAndStatus(stock.getItem(), ReorderStatus.PENDING);

            Optional<Reorders> orderedReorder = reordersRepository
                    .findByItemAndStatus(stock.getItem(), ReorderStatus.ORDERED);

            // Step 3: if no active reorder exists, create one
            if (pendingReorder.isEmpty() && orderedReorder.isEmpty()) {

                Reorders reorder = getReorders(stock);

                reordersRepository.save(reorder);
                newReorders.add(reorder);
            }
        }

        return newReorders;
    }

    private Reorders getReorders(StockLevels stock) {
        int currentQty = stock.getQty() != null ? stock.getQty() : 0;
        int minQty = stock.getMinQty() != null ? stock.getMinQty() : 0;

        // Order enough to reach minimum + half of minimum as buffer
        // Example: minQty=10, currentQty=2 → (10-2) + (10/2) = 13
        int reorderQty = (minQty - currentQty) + (minQty / 2);

        Reorders reorder = new Reorders();
        reorder.setItem(stock.getItem());
        reorder.setSupplier(stock.getItem().getSupplier());
        reorder.setQty(reorderQty);
        reorder.setStatus(ReorderStatus.PENDING);
        return reorder;
    }
}
