package com.Project.backend.service;


import com.Project.backend.exception.ResourceNotFoundException;
import com.Project.backend.model.Items;
import com.Project.backend.repo.ItemsRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ItemsService {


    private final ItemsRepo itemsRepo;

    public List<Items> getAll(){
        return itemsRepo.findAll();
    }

    public Items getById(Long id){
        return itemsRepo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Item not found with id: " + id));
    }

    public List<Items> getByCategory(Long categoryId){
        return itemsRepo.findByCategoryId(categoryId);
    }

    public Items create(Items item){
        return itemsRepo.save(item);
    }

    public Items update(Long Id,Items item){
        Items currentItem=getById(Id);
        currentItem.setName(item.getName());
        currentItem.setCategory(item.getCategory());
        currentItem.setDescription(item.getDescription());
        currentItem.setSupplier(item.getSupplier());
        currentItem.setSku(item.getSku());
        return itemsRepo.save(currentItem);
    }

    public void delete(Long id){
        itemsRepo.deleteById(id);
    }

}
