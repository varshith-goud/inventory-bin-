package com.Project.backend.controller;


import com.Project.backend.model.Items;
import com.Project.backend.service.ItemsService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/items")
@RequiredArgsConstructor
//@CrossOrigin("http://localhost:5173")
public class itemsController {

    private final ItemsService itemsService;
    @GetMapping
    public List<Items> getAll() {
        return itemsService.getAll();
    }

    @GetMapping("/{id}")
    public Items getById(@PathVariable Long id) {
        return itemsService.getById(id);
    }

    @GetMapping("/category/{categoryId}")
    public List<Items> getByCategory(@PathVariable Long categoryId) {
        return itemsService.getByCategory(categoryId);
    }

    @PostMapping
    public Items create(@RequestBody Items item) {
        return itemsService.create(item);
    }

    @PutMapping("/{id}")
    public Items update(@PathVariable Long id, @RequestBody Items item) {
        return itemsService.update(id, item);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        itemsService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
