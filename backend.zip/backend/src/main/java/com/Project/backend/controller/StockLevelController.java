package com.Project.backend.controller;

import com.Project.backend.model.StockLevels;
import com.Project.backend.service.StockLevelsService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/stock")
@RequiredArgsConstructor
public class StockLevelController {

    private final StockLevelsService stockLevelsService;

    @GetMapping
    public List<StockLevels> getAll() {
        return stockLevelsService.getAll();
    }

    @GetMapping("/page")
    public Page<StockLevels> getPaginated(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size,
            @RequestParam(defaultValue = "") String search,
            @RequestParam(required = false) Long categoryId
    ) {
        boolean hasSearch = !search.isEmpty();
        boolean hasCategory = categoryId != null;

        if (hasSearch && hasCategory) {
            return stockLevelsService.searchByCategory(search, categoryId, page, size);
        } else if (hasSearch) {
            return stockLevelsService.search(search, page, size);
        } else if (hasCategory) {
            return stockLevelsService.getByCategory(categoryId, page, size);
        } else {
            return stockLevelsService.getPaginated(page, size);
        }
    }

    @GetMapping("/item/{itemId}")
    public StockLevels getByItemId(@PathVariable Long itemId) {
        return stockLevelsService.getByItemId(itemId);
    }

    @GetMapping("/below-minimum")
    public List<StockLevels> getBelowMin() {
        return stockLevelsService.getItemsBelowMin();
    }

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public StockLevels create(@RequestBody StockLevels stockLevel) {
        return stockLevelsService.create(stockLevel);
    }

    @PutMapping("/{id}/qty")
    public StockLevels updateQty(@PathVariable Long id, @RequestParam int qty) {
        return stockLevelsService.updateQty(id, qty);
    }

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        stockLevelsService.delete(id);
        return ResponseEntity.noContent().build();
    }
}