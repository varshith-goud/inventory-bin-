package com.Project.backend.repo;

import com.Project.backend.model.Items;
import com.Project.backend.model.ReorderStatus;
import com.Project.backend.model.Reorders;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ReordersRepo extends JpaRepository<Reorders,Long> {
    // filter reorders by status (PENDING, ORDERED, DELIVERED)
    List<Reorders> findByStatus(ReorderStatus status);

    // check if a pending reorder already exists for an item
    // used in suggestReorder() to avoid duplicates
    Optional<Reorders> findByItemAndStatus(Items item, ReorderStatus status);
}
