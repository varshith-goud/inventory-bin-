package com.Project.backend.service;

import com.Project.backend.model.ReorderStatus;
import com.Project.backend.model.Reorders;
import com.Project.backend.model.StockLevels;
import com.Project.backend.repo.ReordersRepo;
import com.Project.backend.repo.StockLevelsRepo;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ReordersService {

    private final ReordersRepo reordersRepository;
    private final StockLevelsRepo stockLevelsRepository;

    public List<Reorders> getAll() {
        return reordersRepository.findAll();
    }

    public List<Reorders> getByStatus(ReorderStatus status) {
        return reordersRepository.findByStatus(status);
    }

    public Reorders getById(Long id) {
        return reordersRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Reorder not found with id: " + id));
    }

    public Reorders create(Reorders reorder) {
        return reordersRepository.save(reorder);
    }

    public Reorders updateStatus(Long id, ReorderStatus newStatus) {
        Reorders existing = getById(id);
        existing.setStatus(newStatus);

        // When marked DELIVERED, add the reorder qty back to stock
        if (newStatus == ReorderStatus.DELIVERED) {
            StockLevels stock = stockLevelsRepository.findByItemId(existing.getItem().getId())
                    .orElseThrow(() -> new RuntimeException("Stock not found for item: " + existing.getItem().getName()));

            int currentQty = stock.getQty() != null ? stock.getQty() : 0;
            int reorderQty = existing.getQty() != null ? existing.getQty() : 0;
            stock.setQty(currentQty + reorderQty);
            stockLevelsRepository.save(stock);
        }

        return reordersRepository.save(existing);
    }

    public void delete(Long id) {
        reordersRepository.deleteById(id);
    }
}