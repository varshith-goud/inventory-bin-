package com.Project.backend.model;

public enum ReorderStatus {
    PENDING,
    ORDERED,
    DELIVERED
}