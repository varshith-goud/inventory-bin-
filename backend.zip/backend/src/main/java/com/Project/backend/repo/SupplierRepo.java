package com.Project.backend.repo;

import com.Project.backend.model.Suppliers;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SupplierRepo extends JpaRepository<Suppliers,Long> {


    boolean existsByNameIgnoreCase(String name);
}
