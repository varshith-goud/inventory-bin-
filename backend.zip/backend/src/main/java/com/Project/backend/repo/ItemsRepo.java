package com.Project.backend.repo;

import com.Project.backend.model.Items;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ItemsRepo extends JpaRepository<Items,Long> {
    List<Items> findByCategoryId(Long categoryId);
}
