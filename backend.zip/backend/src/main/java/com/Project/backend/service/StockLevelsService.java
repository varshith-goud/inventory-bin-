package com.Project.backend.service;

import com.Project.backend.model.StockLevels;
import com.Project.backend.repo.StockLevelsRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StockLevelsService {

    private final StockLevelsRepo stockLevelsRepository;

    public List<StockLevels> getAll() {
        return stockLevelsRepository.findAll();
    }

    public Page<StockLevels> getPaginated(int page, int size) {
        return stockLevelsRepository.findAll(PageRequest.of(page, size));
    }

    public Page<StockLevels> search(String keyword, int page, int size) {
        return stockLevelsRepository.searchByKeyword(keyword, PageRequest.of(page, size));
    }

    public Page<StockLevels> getByCategory(Long categoryId, int page, int size) {
        return stockLevelsRepository.findByCategoryId(categoryId, PageRequest.of(page, size));
    }

    public Page<StockLevels> searchByCategory(String keyword, Long categoryId, int page, int size) {
        return stockLevelsRepository.searchByKeywordAndCategory(keyword, categoryId, PageRequest.of(page, size));
    }

    public StockLevels getByItemId(Long itemId) {
        return stockLevelsRepository.findByItemId(itemId)
                .orElseThrow(() -> new RuntimeException("Stock level not found for item id: " + itemId));
    }

    public List<StockLevels> getItemsBelowMin() {
        return stockLevelsRepository.findItemsBelowMin();
    }

    public StockLevels create(StockLevels stockLevel) {
        return stockLevelsRepository.save(stockLevel);
    }

    public StockLevels updateQty(Long id, int newQty) {
        StockLevels existing = stockLevelsRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Stock level not found with id: " + id));
        existing.setQty(newQty);
        return stockLevelsRepository.save(existing);
    }

    public void delete(Long id) {
        stockLevelsRepository.deleteById(id);
    }
}