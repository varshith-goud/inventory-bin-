package com.Project.backend.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "stock_levels")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class StockLevels {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "item_id")
    private Items item;

    @Min(value = 0,message = "Quantity cannot be negative!")
    private Integer qty;

    @Min(value = 0,message = "Quantity cannot be negative!")
    private Integer minQty;
}